@javax.xml.bind.annotation.XmlSchema(namespace = "http://contractfirst.jaxws.examples.camel.wildfly.org/")
package org.wildfly.camel.examples.jaxws.contractfirst;
